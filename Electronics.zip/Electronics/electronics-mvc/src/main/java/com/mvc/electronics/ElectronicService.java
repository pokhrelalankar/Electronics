package com.mvc.electronics;

import java.util.List;

public interface ElectronicService {
	void save(Electronics electronicDevice);
	Electronics findById(int eId);
	List<Electronics> findAll();
	int findCount();
	void deleteById(int eId);
}
