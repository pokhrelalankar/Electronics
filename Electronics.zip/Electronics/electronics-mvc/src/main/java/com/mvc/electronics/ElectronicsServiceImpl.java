package com.mvc.electronics;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public class ElectronicsServiceImpl implements ElectronicService{

	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public void save(Electronics electronicDevice) {
		String sql="insert into electronics_tbl(name,companyName,application,price,yearBought,isWorking) values(?,?,?,?,?,?)";
//		Timestamp timestamp=new Timestamp(new Date().getTime()); 
		Object[] data={electronicDevice.getName(),electronicDevice.getCompanyName(),electronicDevice.getApplication(),
						electronicDevice.getPrice(),electronicDevice.getYearBought(),true};
		//fire the query
		jdbcTemplate.update(sql,data);
	}

	@Override
	public Electronics findById(int eId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Electronics> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int findCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void deleteById(int eId) {
		// TODO Auto-generated method stub
		
	}

}
