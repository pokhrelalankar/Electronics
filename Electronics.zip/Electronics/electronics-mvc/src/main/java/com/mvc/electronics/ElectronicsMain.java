package com.mvc.electronics;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ElectronicsMain {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("electronic-service.xml");
		ElectronicService electronicService=(ElectronicService)applicationContext.getBean("electronicService");
	
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter device name");
		String name=scanner.next();
	
		System.out.println("Enter company name");
		String companyName=scanner.next();
		
		System.out.println("Enter device application");
		String application=scanner.next();
		
		System.out.println("Enter device price");
		int price=Integer.parseInt(scanner.next());
		
		System.out.println("When did you buy it");
		int yearBought=Integer.parseInt(scanner.next());
		
		
		Electronics electronics=new Electronics();
		electronics.setName(name);
		electronics.setCompanyName(companyName);
		electronics.setApplication(application);
		electronics.setPrice(price);
		electronics.setYearBought(yearBought);
		
		electronicService.save(electronics);
		System.out.println("Saved");
		
	
	
	
	
	
	
	}

}
