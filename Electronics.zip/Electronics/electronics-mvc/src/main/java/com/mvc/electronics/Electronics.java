package com.mvc.electronics;
import lombok.Data;

@Data
public class Electronics {
	private int eId;
	private String name;
	private String companyName;
	private String application;
	private int price;
	private int yearBought;
	private boolean isWorking;
}
